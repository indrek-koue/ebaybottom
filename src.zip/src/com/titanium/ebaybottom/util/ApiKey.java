package com.titanium.ebaybottom.util;

public class ApiKey {

	public static final String KEY = "TomThoma-61de-4a88-81bc-38753a959533";
}
