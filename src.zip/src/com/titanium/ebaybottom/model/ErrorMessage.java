package com.titanium.ebaybottom.model;

import java.util.List;

public class ErrorMessage {

	private List<Error> error;

	public List<Error> getError() {
		return error;
	}

	public void setError(List<Error> error) {
		this.error = error;
	}
}
