
package com.titanium.ebaybottom.model;

import java.util.List;

public class ProductId{
   	private String __value__;
   	private String type;

 	public String get__value__(){
		return this.__value__;
	}
	public void set__value__(String __value__){
		this.__value__ = __value__;
	}
 	public String getType(){
		return this.type;
	}
	public void setType(String type){
		this.type = type;
	}
}
